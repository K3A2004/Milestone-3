package com.example.empoweringthenation

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class FirstAidActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_first_aid)

        // Set up the ListView with content
        val contentList = findViewById<ListView>(R.id.contentList)
        val contentItems = listOf(
            "Wounds and Bleeding",
            "Burns and fractures",
            "Emergency scene management",
            "Cardio-Pulmonary Resuscitation (CPR)",
            "Respiratory distress e.g., Choking, blocked airway"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, contentItems)
        contentList.adapter = adapter

        // Set up button to navigate to services
        val servicesButton = findViewById<Button>(R.id.servicesButton)
        servicesButton.setOnClickListener {
            val intent = Intent(this, ServicesActivity::class.java)
            startActivity(intent)
        }
    }
}
