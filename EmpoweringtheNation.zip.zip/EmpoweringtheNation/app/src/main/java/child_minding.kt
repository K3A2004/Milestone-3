package com.example.empoweringthenation

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class ChildMindingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_child_minding)

        // Set up the ListView with content
        val contentList = findViewById<ListView>(R.id.contentList)
        val contentItems = listOf(
            "Birth to six-month old baby needs",
            "Seven-month to one year old needs",
            "Toddler needs",
            "Educational toys"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, contentItems)
        contentList.adapter = adapter

        // Set up button to navigate to services
        val servicesButton = findViewById<Button>(R.id.servicesButton)
        servicesButton.setOnClickListener {
            val intent = Intent(this, ServicesActivity::class.java)
            startActivity(intent)


        }
    }
}
