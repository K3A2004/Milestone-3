package com.example.empoweringthenation.com.example.empoweringthenation

// src/main/java/com/example/empoweringthenation/AboutActivity.kt

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.empoweringthenation.R

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        // Set up email link
        findViewById<TextView>(R.id.email).setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:empoweringthenation@gmail.com")
            }
            startActivity(intent)
        }

        // Set up navigation to home
        findViewById<TextView>(R.id.nav_home).setOnClickListener {
            finish() // This returns to the Home screen if using finish() here
        }
    }
}
