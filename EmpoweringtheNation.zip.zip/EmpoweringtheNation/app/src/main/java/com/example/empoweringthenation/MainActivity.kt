// src/main/java/com/example/empoweringthenation/MainActivity.kt

package com.example.empoweringthenation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.empoweringthenation.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


    }

}
