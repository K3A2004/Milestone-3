package com.example.empoweringthenation




// src/main/java/com/example/empoweringthenation/HomeActivity.kt

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.empoweringthenation.R
import com.example.empoweringthenation.com.example.empoweringthenation.AboutActivity

class HomeActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main
        )
        // Set up navigation links
        findViewById<TextView>(R.id.nav_about).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        // In HomeActivity.kt
        findViewById<TextView>(R.id.nav_services).setOnClickListener {
            startActivity(Intent(this, ServicesActivity::class.java))
        }
        // In HomeActivity.kt
        findViewById<TextView>(R.id.nav_discounts).setOnClickListener {
            startActivity(Intent(this, DiscountsActivity::class.java))
        }
        // In HomeActivity.kt
        findViewById<TextView>(R.id.nav_contact).setOnClickListener {
            startActivity(Intent(this, ContactActivity::class.java))
        }

    }

    }

