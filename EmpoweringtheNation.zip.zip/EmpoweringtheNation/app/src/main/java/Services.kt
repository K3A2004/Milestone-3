// src/main/java/com/example/empoweringthenation/ServicesActivity.kt

package com.example.empoweringthenation

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ServicesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_services)

        // Course price data
        val courses = mapOf(
            "First Aid" to 1500,
            "Sewing" to 1500,
            "Landscaping" to 1500,
            "Life Skills" to 1500,
            "Child Minding" to 750,
            "Cooking" to 750,
            "Garden Maintenance" to 750
        )

        // Initialize UI components
        val quoteTextView = findViewById<TextView>(R.id.quote)
        val calculateButton = findViewById<Button>(R.id.calculate_button)

        calculateButton.setOnClickListener {
            // Calculate total fees
            val selectedCourses = mutableListOf<Int>()
            courses.forEach { (name, price) ->
                val checkBoxId = resources.getIdentifier(name.replace(" ", "_"), "id", packageName)
                val checkBox = findViewById<CheckBox>(checkBoxId)
                if (checkBox.isChecked) selectedCourses.add(price)
            }

            if (selectedCourses.isEmpty()) {
                Toast.makeText(this, "Please select at least one course.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Calculate total, apply discount and VAT
            val total = selectedCourses.sum()
            val discount = when (selectedCourses.size) {
                2 -> 0.05
                3 -> 0.10
                in 4..Int.MAX_VALUE -> 0.15
                else -> 0.0
            }
            val discountedTotal = total - (total * discount)
            val finalTotal = discountedTotal * 1.15  // 15% VAT

            // Display result
            quoteTextView.text = "Total: R${"%.2f".format(finalTotal)} (including VAT and discount)"
        }
    }
}
